(function(callback){ 
var models = [];
models.push({"id":"twaver.idc.table.serva.tab_bb6","modelType":"objModel","width":260.39,"depth":530,"category":"table","height":80.01,"fileName":"table.serva.tab_bb6","showShadow":false});
if(callback)callback(models);
})(it.ModelPlugin)