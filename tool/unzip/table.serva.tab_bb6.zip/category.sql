insert into category(id,system,description,visible,stop_alarm_propagationable,search_filter,performance_url,createdAt,updatedAt,level) value('table',0,'',1,1,1,null,now(),now(),50);
